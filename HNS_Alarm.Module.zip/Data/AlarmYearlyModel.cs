﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Onthesys.ExeBuild
{
    [System.Serializable]
    public class AlarmYearlyModel
    {
        public string areanm;
        public int ala0;
        public int ala1;
        public int ala2;
    }
}
