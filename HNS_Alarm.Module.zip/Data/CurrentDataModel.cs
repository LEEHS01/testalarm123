﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Onthesys.ExeBuild
{
    [System.Serializable]
    public class CurrentDataModel
    {
        public int hnsidx;
        public int boardidx;
        public string stcd;
        public float? val;
        public float hihi;
        public float hi;
        public string useyn;
        public string fix;
    }
}
