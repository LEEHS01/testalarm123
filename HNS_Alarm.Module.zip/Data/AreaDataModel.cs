﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Onthesys.ExeBuild
{
    [System.Serializable]
    public class AreaDataModel
    {
        public int areaIdx;
        public string areaNm;
        public int areaType;
        public string areaTypeNm;
    }
}
