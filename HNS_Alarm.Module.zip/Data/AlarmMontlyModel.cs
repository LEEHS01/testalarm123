﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Onthesys.ExeBuild
{
    [System.Serializable]
    public class AlarmMontlyModel
    {
        public string areanm;
        public int cnt;
    }
}
