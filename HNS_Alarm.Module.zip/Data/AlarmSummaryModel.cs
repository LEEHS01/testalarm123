﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Onthesys.ExeBuild
{
    [System.Serializable]
    public class AlarmSummaryModel
    {
        public int obsidx;
        public int month;
        public int year;
        public int cnt;
    }
}
